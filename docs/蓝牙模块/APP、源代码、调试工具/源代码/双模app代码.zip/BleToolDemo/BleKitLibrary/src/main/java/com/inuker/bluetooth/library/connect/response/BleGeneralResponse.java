package com.inuker.bluetooth.library.connect.response;

import android.os.Bundle;

/**
 * Created by dingjikerbo on 2016/10/11.
 */
public interface BleGeneralResponse extends BleTResponse<Bundle> {
}
