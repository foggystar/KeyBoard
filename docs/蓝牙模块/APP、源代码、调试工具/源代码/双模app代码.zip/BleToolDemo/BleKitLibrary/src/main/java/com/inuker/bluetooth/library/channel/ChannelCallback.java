package com.inuker.bluetooth.library.channel;

/**
 * Created by dingjikerbo on 17/4/17.
 */

public interface ChannelCallback {

    void onCallback(int code);
}
