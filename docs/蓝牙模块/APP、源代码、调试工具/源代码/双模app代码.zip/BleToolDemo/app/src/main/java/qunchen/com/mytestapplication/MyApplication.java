package qunchen.com.mytestapplication;

import android.app.Application;
import android.content.Context;

import com.tencent.bugly.crashreport.CrashReport;

/**
 * Created by chen on 2018/5/31.
 */
public class MyApplication extends Application {
    private static Context mContext;

    @Override
    public void onCreate() {
        super.onCreate();
        mContext = this;
        CrashReport.initCrashReport(getApplicationContext(), "414bfbf141", false);
    }

    public static Context getContext() {
        return mContext;
    }
}
