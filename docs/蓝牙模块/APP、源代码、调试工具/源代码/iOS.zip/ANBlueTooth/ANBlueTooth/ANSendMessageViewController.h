//
//  ANSendMessageViewController.h
//  ANBlueTooth
//
//  Created by 王进盛 on 2017/12/3.
//  Copyright © 2017年 ania. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
#import "EasyPeripheral.h"

@interface ANSendMessageViewController : BaseViewController

@property (nonatomic,strong)EasyPeripheral *peripheral ;

@end
