//
//  AppDelegate.h
//  ANBlueTooth
//
//  Created by 王进盛 on 2017/12/2.
//  Copyright © 2017年 ania. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "EasyCharacteristic.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) EasyCharacteristic *currentCharacteristic;
@property (strong, nonatomic) NSMutableArray * currentNotiyCharacteristic;

+ (AppDelegate *)appDelegate;


@end

