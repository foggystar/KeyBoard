//
//  ALTextAttributedString.h
//  rocketBrowser
//
//  Created by 周广生 on 16/3/9.
//  Copyright © 2016年 周广生. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface ALTextAttributedString : NSObject

+ (NSDictionary *)TextAttrDictUseSystemFontWithTextSize:(CGFloat)size
                                        andTextColorStr:(NSString *)colorStr;
+ (NSDictionary *)TextAttrDictUseSystemFontWithTextSize:(CGFloat)size
                                        andTextColor:(UIColor *)color;

+ (NSAttributedString *)TextAttrStringUseSystemFontForText:(NSString *)text
                                              WithTextSize:(CGFloat)size
                                           andTextColorStr:(NSString *)colorStr;
+ (NSAttributedString *)TextAttrStringUseSystemFontForText:(NSString *)text
                                              WithTextSize:(CGFloat)size
                                           andTextColor:(UIColor *)color;

@end
