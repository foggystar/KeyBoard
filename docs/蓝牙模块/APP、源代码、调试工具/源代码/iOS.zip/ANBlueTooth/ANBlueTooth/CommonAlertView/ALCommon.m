//
//  ALCommon.m
//  JuShaSDKBuild
//
//  Created by 周广生 on 16/4/1.
//  Copyright © 2016年 周广生. All rights reserved.
//

#import "ALCommon.h"

#import "UIColor+Hex.h"
#import "ALTextAttributedString.h"

@interface ALCommon ()

//@property (nonatomic, readwrite, getter=isNetWorkReachable) BOOL netWorkReachable;

@end

@implementation ALCommon

//+ (instancetype)shareManager
//{
//    static ALCommon *_shareManager = nil;
//    
//    static dispatch_once_t onceToken;
//    dispatch_once(&onceToken, ^{
//        _shareManager = [[ALCommon alloc] init];
//    });
//    
//    return _shareManager;
//}

//+(UIColor *)titleTextColor{
//    return [UIColor colorWithCSS:@"#7d7d7d"];
//}
//
//+(UIColor *)lightGrayColor{
//    return [UIColor colorWithCSS:@"#efefef"];
//}
//
//+(UIColor *)redColor{
//    return [UIColor colorWithCSS:@"#fe6253"];
//}

//+(UIColor *)blueColor{
//    return [UIColor colorWithCSS:@"#38AFEF"];
//}
//

+(UIColor *)controllerBgColor{
    return [UIColor colorWithCSS:@"#efeff4"];
}

+(UIColor *)lightRedColor{
    return [UIColor colorWithCSS:@"#f95a70"];
}

+(UIColor *)lightGrayColor{
    return [UIColor colorWithCSS:@"#999999"];
}

+(UIColor *)tabSelectedColor{
    return [UIColor colorWithCSS:@"#0c9494"];
}

+(UIColor *)tabUnselectedColor{
    return [UIColor colorWithCSS:@"#999999"];
}

+(void)showPromptMessageInPoint:(CGPoint)point text:(NSString *)text duration:(NSTimeInterval)duration{
    CGSize windowSize = [UIScreen mainScreen].bounds.size;
    
    NSStringDrawingOptions opts = NSStringDrawingUsesLineFragmentOrigin |
    NSStringDrawingUsesFontLeading;
    NSDictionary *attrDic = [ALTextAttributedString TextAttrDictUseSystemFontWithTextSize:windowSize.width/22 andTextColor:[UIColor whiteColor]];
    NSAttributedString *attrStr = [[NSAttributedString alloc] initWithString:text attributes:attrDic];
    CGRect textSize = [text boundingRectWithSize:CGSizeMake(windowSize.width, CGFLOAT_MAX) options:opts attributes:attrDic context:nil];
    
    CGFloat tipLabelWidth = textSize.size.width+20;
    CGFloat tipLabelHeight = textSize.size.height+15;
    UILabel *tipLabel = [[UILabel alloc] initWithFrame:CGRectMake(point.x-tipLabelWidth/2, point.y-tipLabelHeight/2, tipLabelWidth, tipLabelHeight)];
    tipLabel.lineBreakMode = NSLineBreakByWordWrapping;
    tipLabel.numberOfLines = 0;
    tipLabel.backgroundColor = [UIColor blackColor];
    tipLabel.alpha = 0.8;
    tipLabel.layer.cornerRadius = 10;
    tipLabel.layer.masksToBounds = YES;
    //    tipLabel.textColor = [UIColor whiteColor];
    tipLabel.attributedText = attrStr;
    tipLabel.textAlignment = NSTextAlignmentCenter;
    //    tipLabel.text = @"成功添加";
    UIWindow * window = [UIApplication sharedApplication].keyWindow;
    [window addSubview:tipLabel];
    
    [UIView animateWithDuration:duration animations:^{
        tipLabel.alpha = 0;
    } completion:^(BOOL finished) {
        [tipLabel removeFromSuperview];
    }];
}

//+(NSString *)getRandomStr{
//    NSString *randomStr = @"";
//    
//    for(int i=0; i<6; i++)
//        randomStr = [randomStr stringByAppendingFormat:@"%i",(arc4random() % 9)];
//    
//    return randomStr;
//}
//
//+(NSDateFormatter *)getDateFormatter{
//    NSDateFormatter *dateFormatter;
//    
//    dateFormatter = [[NSDateFormatter alloc] init];
//    dateFormatter.dateFormat = @"yyyyMMdd";
//    dateFormatter.locale = [NSLocale currentLocale];
//    dateFormatter.timeZone = [NSTimeZone systemTimeZone];
//    
//    return dateFormatter;
//}

@end
