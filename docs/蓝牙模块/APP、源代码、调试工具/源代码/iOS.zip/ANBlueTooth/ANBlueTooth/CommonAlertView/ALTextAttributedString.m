//
//  ALTextAttributedString.m
//  rocketBrowser
//
//  Created by 周广生 on 16/3/9.
//  Copyright © 2016年 周广生. All rights reserved.
//

#import "ALTextAttributedString.h"
#import "UIColor+Hex.h"

@implementation ALTextAttributedString

+ (NSDictionary *)TextAttrDictUseSystemFontWithTextSize:(CGFloat)size
                                        andTextColorStr:(NSString *)colorStr {
    
    NSMutableDictionary *attrs = [[NSMutableDictionary alloc] init];
    if (size > 0) {
        UIFont *font = [UIFont systemFontOfSize:size];
        [attrs setObject:font forKey:NSFontAttributeName];
    }
    if (colorStr) {
        UIColor *color = [UIColor colorWithCSS:colorStr];
        [attrs setObject:color forKey:NSForegroundColorAttributeName];
    }else{
        [attrs setObject:[UIColor blackColor] forKey:NSForegroundColorAttributeName];
    }
    return attrs;
}

+ (NSDictionary *)TextAttrDictUseSystemFontWithTextSize:(CGFloat)size
                                           andTextColor:(UIColor *)color{
    
    NSMutableDictionary *attrs = [[NSMutableDictionary alloc] init];
    if (size > 0) {
        UIFont *font = [UIFont systemFontOfSize:size];
        [attrs setObject:font forKey:NSFontAttributeName];
    }
    if (color) {
        [attrs setObject:color forKey:NSForegroundColorAttributeName];
    }
//    else{
//        [attrs setObject:[UIColor blackColor] forKey:NSForegroundColorAttributeName];
//    }
    return attrs;
}

+ (NSAttributedString *)TextAttrStringUseSystemFontForText:(NSString *)text
                                              WithTextSize:(CGFloat)size
                                           andTextColorStr:(NSString *)colorStr; {
    
    NSDictionary *attrs = [ALTextAttributedString TextAttrDictUseSystemFontWithTextSize:size andTextColorStr:colorStr];
    
    return [[NSAttributedString alloc] initWithString:text attributes:attrs];
}

+ (NSAttributedString *)TextAttrStringUseSystemFontForText:(NSString *)text
                                              WithTextSize:(CGFloat)size
                                              andTextColor:(UIColor *)color{
    
    NSDictionary *attrs = [ALTextAttributedString TextAttrDictUseSystemFontWithTextSize:size andTextColor:color];
    
    return [[NSAttributedString alloc] initWithString:text attributes:attrs];
}



@end
