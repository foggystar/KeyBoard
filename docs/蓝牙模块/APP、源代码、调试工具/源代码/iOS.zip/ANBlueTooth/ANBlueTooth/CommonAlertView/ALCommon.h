//
//  ALCommon.h
//  JuShaSDKBuild
//
//  Created by 周广生 on 16/4/1.
//  Copyright © 2016年 周广生. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface ALCommon : NSObject

//+ (instancetype)shareManager;

//+(UIColor *)titleTextColor;
//
//+(UIColor *)lightGrayColor;
//
//+(UIColor *)redColor;

//+(UIColor *)blueColor;

+(UIColor *)controllerBgColor; //浅灰
+(UIColor *)lightRedColor;
+(UIColor *)lightGrayColor;

+(UIColor *)tabSelectedColor;
+(UIColor *)tabUnselectedColor;
//
//point 为中心点
+(void)showPromptMessageInPoint:(CGPoint)point text:(NSString *)text duration:(NSTimeInterval)duration;
//
//+(NSString *)getRandomStr;
//
//+(NSDateFormatter *)getDateFormatter;

@end
