//
//  BaseViewController.m
//  KeyDiyKD
//
//  Created by 朱年生 on 15/10/12.
//  Copyright © 2015年 深圳市宜车科技有限公司. All rights reserved.
//

#import "BaseViewController.h"

@interface BaseViewController ()

@end

@implementation BaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    UIImage     * normal        = [UIImage imageNamed:@"new_back"];
    UIImage     * pressed       = [UIImage imageNamed:@"new_back"];
    UIButton    * backButton  = [UIButton buttonWithType:UIButtonTypeCustom];
    [backButton setImage:normal forState:UIControlStateNormal];
    [backButton setImage:pressed forState:UIControlStateHighlighted];
    [backButton setTitle:@"返回" forState:UIControlStateNormal];
    [backButton setTitleColor:[UIColor darkGrayColor] forState:UIControlStateNormal];
    [backButton setFrame:CGRectMake(0, 0, 60, 60)];
    [backButton addTarget:self action:@selector(popToRootView) forControlEvents:UIControlEventTouchUpInside];
    
    self.navigationItem.leftBarButtonItem   = [[UIBarButtonItem alloc] initWithCustomView:backButton];
}

- (void)viewWillAppear:(BOOL)animated{
    [UIView animateWithDuration:1 animations:^{
        [self.tabBarController.tabBar setHidden:YES];
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)popToRootView
{
    if (self.navigationController.viewControllers.count ==1) {
        [self dismissViewControllerAnimated:YES completion:nil];
        return;
    }
    
    [self.navigationController popViewControllerAnimated:YES];
    
}

- (void)doubleTapViewClose {
    CATransition* transition = [CATransition animation];
    //执行时间长短
    transition.duration = 0.2;
    //动画的开始与结束的快慢
    transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    //各种动画效果
    transition.type = kCATransitionFade; //kCATransitionMoveIn, kCATransitionPush, kCATransitionReveal, kCATransitionFade
    //动画方向
    //transition.subtype = kCATransitionFromTop; //kCATransitionFromLeft, kCATransitionFromRight, kCATransitionFromTop, kCATransitionFromBottom
    //将动画添加在视图层上
    [self.navigationController.view.layer addAnimation:transition forKey:nil];
    [[self navigationController] popViewControllerAnimated:NO];
}

@end
