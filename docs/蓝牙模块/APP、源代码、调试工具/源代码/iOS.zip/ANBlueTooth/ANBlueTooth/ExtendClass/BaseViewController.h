//
//  BaseViewController.h
//  KeyDiyKD
//
//  Created by 朱年生 on 15/10/12.
//  Copyright © 2015年 深圳市宜车科技有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseViewController : UIViewController

- (void)popToRootView;

@end
