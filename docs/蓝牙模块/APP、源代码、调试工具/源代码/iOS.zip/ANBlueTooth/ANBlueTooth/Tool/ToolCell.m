//
//  ToolCell.m
//  EasyBlueTooth
//
//  Created by nf on 2017/8/18.
//  Copyright © 2017年 chenSir. All rights reserved.
//

#import "ToolCell.h"

@interface ToolCell()
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *RSSILabel;
@property (weak, nonatomic) IBOutlet UILabel *stateLabel;
@property (weak, nonatomic) IBOutlet UILabel *servicesLabel;
@property (weak, nonatomic) IBOutlet UIView *rssiShowView;

@end

@implementation ToolCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    self.bottomView.layer.cornerRadius = 5.0F;
    self.bottomView.layer.borderWidth = 3;
    self.bottomView.layer.borderColor = [UIColor colorWithRed:172.0f/255.0f green:225.0f/255.0f blue:146.0f/255.0f alpha:1].CGColor;
}

- (void)setPeripheral:(EasyPeripheral *)peripheral
{
    _peripheral = peripheral ;
    
    self.nameLabel.text = peripheral.name ;
    self.RSSILabel.text = [NSString stringWithFormat:@"%@",peripheral.RSSI ];
    NSArray *serviceArray = [peripheral.advertisementData objectForKey:CBAdvertisementDataServiceUUIDsKey];
    self.servicesLabel.text = [NSString stringWithFormat:@"%zd Services",serviceArray.count];
    
    if (peripheral.state == CBPeripheralStateConnected) {
        self.stateLabel.text = @"已连接";
    }else{
        self.stateLabel.text = @"未连接";
    }
    if (!peripheral.RSSI) {
        self.rssiShowView.backgroundColor = [UIColor redColor];
        return;
    }
    
    if (abs([peripheral.RSSI intValue]) <40) {
        self.rssiShowView.backgroundColor = [UIColor colorWithRed:67.0f/255.0f green:237.0f/255.0f blue:124.0f/255.0f alpha:1];
    }else if (abs([peripheral.RSSI intValue])>=40 && abs([peripheral.RSSI intValue]) <=60){
        self.rssiShowView.backgroundColor = [UIColor colorWithRed:172.0f/255.0f green:225.0f/255.0f blue:146.0f/255.0f alpha:1];
    }else if (abs([peripheral.RSSI intValue])>60 && abs([peripheral.RSSI intValue])<=80){
        self.rssiShowView.backgroundColor = [UIColor colorWithRed:225.0f/255.0f green:225.0f/255.0f blue:255.0f/255.0f alpha:1];
    }else{
        self.rssiShowView.backgroundColor = [UIColor redColor];
    }
}

+ (CGFloat)cellHeight
{
    return 80.0f ;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
