//
//  ToolDetailOperationViewController.h
//  EasyBlueTooth
//
//  Created by Mr_Chen on 17/8/19.
//  Copyright © 2017年 chenSir. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "EasyCharacteristic.h"

@interface ToolDetailOperationViewController : UIViewController

@property (nonatomic,strong)EasyCharacteristic *characteristic ;

@end
